let backgroundColors = document.getElementById("backgroundColors")
let backgroundText = document.getElementById("backgroundText");
let spanLink = document.getElementById("spanLink")

function buttonColor1() {
    document.getElementById("button1").style.backgroundColor = "#e0e0e0"
    backgroundColors.style.backgroundColor = "#e0e0e0"
    backgroundText.style.backgroundColor = "#222222"
    spanLink.textContent = "#e0e0e0"
}
function buttonColor2() {
    document.getElementById("button2").style.backgroundColor = "#6fcf97"
    backgroundColors.style.backgroundColor = "#6fcf97"
    spanLink.textContent = "#6fcf97"
}
function buttonColor3() {
    document.getElementById("button3").style.backgroundColor = "#56ccf2"
    backgroundColors.style.backgroundColor = "#56ccf2"
    spanLink.textContent = "#56ccf2"
}
function buttonColor4() {
    document.getElementById("button4").style.backgroundColor = "#bb6bd9"
    backgroundColors.style.backgroundColor = "#bb6bd9"
    spanLink.textContent = "#bb6bd9"
}