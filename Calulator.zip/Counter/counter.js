let counterElement = document.getElementById('counterValue');

function onDecrement() {
    let priviesCountervalue = counterElement.textContent;
    let updateCountervalue = parseInt(priviesCountervalue) - 1;
    counterElement.textContent = updateCountervalue
    if (updateCountervalue > 0) {
        counterElement.style.color = "green"
    } else if (updateCountervalue < 0) {
        counterElement.style.color = "Red"
    } else {
        counterElement.style.color = "black"
    }

}

function onReset() {
    let updateCountervalue = 0;
    counterElement.textContent = updateCountervalue
    if (updateCountervalue > 0) {
        counterElement.style.color = "green"
    } else if (updateCountervalue < 0) {
        counterElement.style.color = "Red"
    } else {
        counterElement.style.color = "black"
    }
}

function onIncrement() {
    let priviesCountervalue = counterElement.textContent;
    let updateCountervalue = parseInt(priviesCountervalue) + 1;
    counterElement.textContent = updateCountervalue
    if (updateCountervalue > 0) {
        counterElement.style.color = "green"
    } else if (updateCountervalue < 0) {
        counterElement.style.color = "Red"
    } else {
        counterElement.style.color = "black"
    }
}